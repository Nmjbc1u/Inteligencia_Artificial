import csv
import random
import time
from collections import defaultdict

# Pesos dos critérios
WEIGHT_DISTANCE = 1.0
WEIGHT_DURATION = 1.0
WEIGHT_UNLEVEL = 1.0
NEIGHBOR_RADIUS = 1000  # valor ajustável (média das distâncias, opcional)

class Node:
    def __init__(self, name):
        self.name = name
        self.parent = None
        self.cost = float('inf')

class RRTStarGraph:
    def __init__(self, adjacency_matrix):
        self.graph = adjacency_matrix
        self.vertices = []
        self.name_to_node = {}

    def get_neighbors(self, node):
        return self.graph.get(node.name, [])

    def cost_between(self, node1, node2):
        for neighbor, dist, dur, unlevel in self.get_neighbors(node1):
            if neighbor == node2.name:
                return WEIGHT_DISTANCE * dist + WEIGHT_DURATION * dur + WEIGHT_UNLEVEL * unlevel
        return float('inf')

    def random_node(self):
        name = random.choice(list(self.graph.keys()))
        return Node(name)

    def nearest(self, rand_node):
        nearest_node = None
        min_cost = float('inf')
        for node in self.vertices:
            cost = self.cost_between(node, rand_node)
            if cost < min_cost:
                nearest_node = node
                min_cost = cost
        return nearest_node

    def near_nodes(self, new_node):
        near = []
        for node in self.vertices:
            cost = self.cost_between(node, new_node)
            if cost < NEIGHBOR_RADIUS:
                near.append(node)
        return near

    def extract_path(self, goal):
        path = []
        total_dist = total_dur = total_unlevel = 0

        while goal:
            path.append(goal.name)
            if goal.parent:
                for neighbor, dist, dur, unlevel in self.get_neighbors(goal.parent):
                    if neighbor == goal.name:
                        total_dist += dist
                        total_dur += dur
                        total_unlevel += unlevel
            goal = goal.parent

        path.reverse()
        return path, total_dist, total_dur, total_unlevel

    def planning(self, start_name, goal_name, iter_max=1000):
        self.vertices = []
        self.name_to_node = {}
        visited_names = set()

        start_node = Node(start_name)
        start_node.cost = 0
        self.vertices.append(start_node)
        self.name_to_node[start_name] = start_node
        visited_names.add(start_name)

        goal_node = Node(goal_name)

        for _ in range(iter_max):
            rand_node = self.random_node()
            if rand_node.name in visited_names:
                continue

            rand_node = Node(rand_node.name)
            nearest_node = self.nearest(rand_node)

            if not nearest_node:
                continue

            cost = nearest_node.cost + self.cost_between(nearest_node, rand_node)
            rand_node.cost = cost
            rand_node.parent = nearest_node

            # Escolher melhor pai entre os vizinhos
            neighbors = self.near_nodes(rand_node)
            for neighbor in neighbors:
                c = neighbor.cost + self.cost_between(neighbor, rand_node)
                if c < rand_node.cost:
                    rand_node.parent = neighbor
                    rand_node.cost = c

            self.vertices.append(rand_node)
            self.name_to_node[rand_node.name] = rand_node
            visited_names.add(rand_node.name)

            for neighbor in neighbors:
                c = rand_node.cost + self.cost_between(rand_node, neighbor)
                if c < neighbor.cost:
                    neighbor.parent = rand_node
                    neighbor.cost = c

            if rand_node.name == goal_node.name:
                goal_node.parent = rand_node.parent
                goal_node.cost = rand_node.cost
                return self.extract_path(goal_node)

        return None, None, None, None

# Carregar o grafo a partir do CSV
adjacency_matrix = defaultdict(list)

with open("viana_streets_network_named.csv", "rt", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for linha in reader:
        origin = linha["origin"]
        destination = linha["destination"]
        distance = float(linha["distance_meters"])
        duration = float(linha["duration_minutes"])
        unlevel = float(linha["unlevel_percent"])
        adjacency_matrix[origin].append((destination, distance, duration, unlevel))

# Definir pontos de partida e chegada
start_city = "Rua do Povoeiros"
goal_city = "Rua de Olivença"

melhor_caminho = None
menor_custo_total = float('inf')
total_nos_expandidos = 0

start_time = time.perf_counter()

for i in range(5):
    graph = RRTStarGraph(adjacency_matrix)
    caminho, distancia, duracao, desnível = graph.planning(start_city, goal_city, iter_max=2000)

    total_nos_expandidos += len(graph.vertices)

    if caminho:
        custo_total = WEIGHT_DISTANCE * distancia + WEIGHT_DURATION * duracao + WEIGHT_UNLEVEL * desnível
        print(f"\nCaminho {i+1}: {caminho}")
        print(f"Distância: {distancia:.2f} m")
        print(f"Duração: {duracao:.2f} min")
        print(f"Desnível: {desnível:.2f} %")
        print(f"Custo total: {custo_total:.2f}")

        if custo_total < menor_custo_total:
            menor_custo_total = custo_total
            melhor_caminho = (caminho, distancia, duracao, desnível, custo_total)
    else:
        print(f"Caminho {i+1}: Não encontrado\n")

end_time = time.perf_counter()
elapsed_time = end_time - start_time

if melhor_caminho:
    print("\nMelhor Caminho Encontrado:")
    print(f"Caminho: {melhor_caminho[0]}")
    print(f"Distância: {melhor_caminho[1]:.2f} m")
    print(f"Duração: {melhor_caminho[2]:.2f} min")
    print(f"Desnível: {melhor_caminho[3]:.2f} %")
    print(f"Custo total: {melhor_caminho[4]:.2f}")
    print(f"\nNodes expandidos no total: {total_nos_expandidos}")
    print(f"Média de nodes expandidos por execução: {total_nos_expandidos / 5:.2f}")
    print(f"Tempo de execução: {elapsed_time:.4f} segundos")
else:
    print("Nenhum caminho encontrado.")
