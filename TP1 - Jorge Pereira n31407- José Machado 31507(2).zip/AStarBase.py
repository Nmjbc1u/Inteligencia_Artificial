import csv
import time
from math import radians, cos, sin, sqrt, atan2
from heapq import heappush, heappop

# Pesos ajustáveis
WEIGHT_DISTANCE = 1.0
WEIGHT_DURATION = 1.0
WEIGHT_UNLEVEL = 1.0

def haversine(lon1, lat1, lon2, lat2):
    R = 6371000  # Raio da Terra em metros
    dlon = radians(lon2 - lon1)
    dlat = radians(lat2 - lat1)
    a = sin(dlat / 2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

class Graph:
    def __init__(self, nodes, adjacency_matrix, node_coords):
        self.nodes = nodes
        self.adjacency_matrix = adjacency_matrix
        self.coords = node_coords
        self.goal_node = None

    def h(self, n):
        lon1, lat1 = self.coords.get(n, (0, 0))
        lon2, lat2 = self.coords.get(self.goal_node, (0, 0))
        return WEIGHT_DISTANCE * haversine(lon1, lat1, lon2, lat2)

    def get_neighbors(self, v):
        index = self.nodes.index(v)
        neighbors = []
        for i, cost in enumerate(self.adjacency_matrix[index]):
            if cost is not None:
                neighbors.append((self.nodes[i], *cost))
        return neighbors

    def a_star_algorithm(self, start_node, stop_node):
        self.goal_node = stop_node
        open_heap = []
        heappush(open_heap, (0 + self.h(start_node), start_node))
        g = {start_node: 0}
        parents = {start_node: start_node}
        nodes_visitados = 0
        closed_set = set()

        while open_heap:
            _, n = heappop(open_heap)

            if n in closed_set:
                continue

            nodes_visitados += 1
            closed_set.add(n)

            if n == stop_node:
                path = []
                total_dist = total_dur = total_unlevel = 0
                while parents[n] != n:
                    path.append(n)
                    for neighbor, dist, dur, unlevel in self.get_neighbors(parents[n]):
                        if neighbor == n:
                            total_dist += dist
                            total_dur += dur
                            total_unlevel += unlevel
                    n = parents[n]
                path.append(start_node)
                path.reverse()

                print("\nCaminho final:", " -> ".join(path))
                print(f"Custo total: {total_dist + total_dur + total_unlevel:.2f}")
                print(f"  Distância: {total_dist:.2f} m")
                print(f"  Duração: {total_dur:.2f} min")
                print(f"  Desnível: {total_unlevel:.2f} %")
                print("Nodes percorridos:", nodes_visitados)
                return path

            for m, dist, dur, unlevel in self.get_neighbors(n):
                weight = (
                    WEIGHT_DISTANCE * dist
                    + WEIGHT_DURATION * dur
                    + WEIGHT_UNLEVEL * unlevel
                )
                tentative_g = g[n] + weight

                if m not in g or tentative_g < g[m]:
                    g[m] = tentative_g
                    priority = tentative_g + self.h(m)
                    heappush(open_heap, (priority, m))
                    parents[m] = n

        print("Caminho não encontrado.")
        return None

# =========================
# Carregar dados do CSV
# =========================
nodes = set()
edges = []
coords = {}

with open("viana_streets_network_named.csv", "rt", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for linha in reader:
        origin = linha["origin"]
        destination = linha["destination"]
        distance = float(linha["distance_meters"])
        duration = float(linha["duration_minutes"])
        unlevel = float(linha["unlevel_percent"])
        lon = float(linha["intersect_lon"])
        lat = float(linha["intersect_lat"])

        nodes.add(origin)
        nodes.add(destination)
        edges.append((origin, destination, distance, duration, unlevel))

        if origin not in coords:
            coords[origin] = (lon, lat)

nodes = sorted(nodes)
index_map = {node: i for i, node in enumerate(nodes)}
adj_matrix = [[None for _ in nodes] for _ in nodes]

for origin, destination, dist, dur, unlevel in edges:
    i = index_map[origin]
    j = index_map[destination]
    adj_matrix[i][j] = (dist, dur, unlevel)

graph = Graph(nodes, adj_matrix, coords)

start = "Rua do Povoeiros"
end = "Rua de Olivença"

start_time = time.perf_counter()
graph.a_star_algorithm(start, end)
end_time = time.perf_counter()

print(f"Tempo de execução: {end_time - start_time:.4f} segundos")