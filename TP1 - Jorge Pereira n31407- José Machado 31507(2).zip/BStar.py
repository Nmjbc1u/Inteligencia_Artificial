import csv
import time
from math import radians, cos, sin, sqrt, atan2

# Pesos ajustáveis
WEIGHT_DISTANCE = 1.0
WEIGHT_DURATION = 1.0
WEIGHT_UNLEVEL = 1.0

def haversine(lon1, lat1, lon2, lat2):
    R = 6371000  # raio da Terra em metros
    dlon = radians(lon2 - lon1)
    dlat = radians(lat2 - lat1)
    a = sin(dlat / 2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

class Graph:
    def __init__(self, nodes, adjacency_matrix, coords):
        self.nodes = nodes
        self.adjacency_matrix = adjacency_matrix
        self.coords = coords
        self.goal_node = None

    def h(self, n):
        lon1, lat1 = self.coords[n]
        lon2, lat2 = self.coords[self.goal_node]
        return WEIGHT_DISTANCE * haversine(lon1, lat1, lon2, lat2)

    def get_neighbors(self, v):
        index = self.nodes.index(v)
        neighbors = []
        for i, cost in enumerate(self.adjacency_matrix[index]):
            if cost is not None:
                neighbors.append((self.nodes[i], *cost))
        return neighbors

    def b_star_algorithm(self, start_node, stop_node):
        self.goal_node = stop_node
        open_list = {start_node}
        closed_list = set()
        g = {start_node: 0}
        f_lower = {start_node: 0}
        f_upper = {start_node: 0}
        parents = {start_node: start_node}
        nodes_visitados = 0

        while open_list:
            n = min(open_list, key=lambda x: f_lower[x] + self.h(x))

            if n == stop_node:
                reconst_path = []
                total_dist = total_dur = total_unlevel = 0
                while parents[n] != n:
                    reconst_path.append(n)
                    for neighbor, dist, dur, unlevel in self.get_neighbors(parents[n]):
                        if neighbor == n:
                            total_dist += dist
                            total_dur += dur
                            total_unlevel += unlevel
                    n = parents[n]
                reconst_path.append(start_node)
                reconst_path.reverse()

                print("\nCaminho final:", " -> ".join(reconst_path))
                print("Custo total: {:.2f}".format(total_dist + total_dur + total_unlevel))
                print(f"  Distância (m): {total_dist:.2f}")
                print(f"  Duração (min): {total_dur:.2f}")
                print(f"  Desnível (%): {total_unlevel:.2f}")
                print(f"Nodes percorridos: {nodes_visitados}")
                return reconst_path

            nodes_visitados += 1
            open_list.remove(n)
            closed_list.add(n)

            for (m, dist, dur, unlevel) in self.get_neighbors(n):
                weight = (
                    WEIGHT_DISTANCE * dist
                    + WEIGHT_DURATION * dur
                    + WEIGHT_UNLEVEL * unlevel
                )
                f_lower_m = g[n] + weight
                f_upper_m = g[n] + weight + self.h(m)

                if m not in open_list and m not in closed_list:
                    open_list.add(m)
                    parents[m] = n
                    g[m] = g[n] + weight
                    f_lower[m] = f_lower_m
                    f_upper[m] = f_upper_m
                elif g[m] > g[n] + weight:
                    g[m] = g[n] + weight
                    parents[m] = n
                    f_lower[m] = f_lower_m
                    f_upper[m] = f_upper_m
                    if m in closed_list:
                        closed_list.remove(m)
                        open_list.add(m)

        print("Caminho não encontrado.")
        print("Nodes expandidos:", nodes_visitados)
        return None

# ======= Leitura do CSV e construção do grafo =======
nodes = set()
edges = []
coords = {}

with open("viana_streets_network_named.csv", "rt", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for linha in reader:
        origin = linha["origin"]
        destination = linha["destination"]
        distance = float(linha["distance_meters"])
        duration = float(linha["duration_minutes"])
        unlevel = float(linha["unlevel_percent"])
        lon = float(linha["intersect_lon"])
        lat = float(linha["intersect_lat"])

        nodes.add(origin)
        nodes.add(destination)
        edges.append((origin, destination, distance, duration, unlevel))

        if origin not in coords:
            coords[origin] = (lon, lat)

nodes = sorted(nodes)
nodes_index = {node: i for i, node in enumerate(nodes)}
adjacency_matrix = [[None] * len(nodes) for _ in range(len(nodes))]

for origin, destination, dist, dur, unlevel in edges:
    i = nodes_index[origin]
    j = nodes_index[destination]
    adjacency_matrix[i][j] = (dist, dur, unlevel)

graph = Graph(nodes, adjacency_matrix, coords)

start_node = "Rua do Povoeiros"
end_node = "Rua de Olivença"

start_time = time.perf_counter()
graph.b_star_algorithm(start_node, end_node)
end_time = time.perf_counter()

print(f"Tempo de execução: {end_time - start_time:.4f} segundos")
